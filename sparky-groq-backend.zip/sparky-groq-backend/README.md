# Sparky Groq Backend

A Netlify backend for Sparky using Groq AI API (free tier).

## Setup Instructions

### 1. Get Groq API Key
- Go to https://console.groq.com
- Sign up (free)
- Create API key
- Save it

### 2. Create GitHub Repo
1. Go to https://github.com/new
2. Name it `sparky-groq-backend`
3. Initialize with README (uncheck)
4. Create repository

### 3. Upload Files to GitHub

In terminal:
```bash
cd sparky-groq-backend
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/sparky-groq-backend.git
git push -u origin main
```

### 4. Deploy to Netlify
1. Go to https://app.netlify.com
2. Click "Add new site"
3. Choose "Import an existing project"
4. Select GitHub
5. Choose `sparky-groq-backend`
6. Click Deploy

### 5. Add Environment Variable
1. In Netlify dashboard, go to your site
2. Click "Site settings"
3. Go to "Build & deploy" > "Environment"
4. Click "Edit variables"
5. Add:
   - Key: `GROQ_API_KEY`
   - Value: Your Groq API key

### 6. Update Your Extension

In your extension's `background.js`, change the DEFAULT_BASE:

```javascript
const DEFAULT_BASE = "https://YOUR-SITE-NAME.netlify.app/api";
```

Replace `YOUR-SITE-NAME` with your actual Netlify site name.

### 7. Test It

Your backend will be live at:
- `https://YOUR-SITE-NAME.netlify.app/.netlify/functions/screen-help`
- `https://YOUR-SITE-NAME.netlify.app/.netlify/functions/healthz`

Done! 🎉
